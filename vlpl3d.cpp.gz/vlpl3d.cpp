#include <stdio.h>
#include <stdlib.h>
#include <iostream>

#define X_ACCESS

#include "vlpl3d.h"

int main(int argc, char** argv)
{
  char* infile;

  int rank = 0;
  int myid, numprocs;
  int  namelen;

#ifdef V_MPI
  char processor_name[MPI_MAX_PROCESSOR_NAME];
#endif

  if (argc < 2) {
	cout << "Usage: vlpl1d <ini-file> \n";
	cout << "Default name: v.ini will be used \n";
    //    return -10;
    infile = "v.ini";
  } else {
    infile = argv[1];
    cout << "The start file is: " << argv[1] << " \n";
  }

infile = "v.ini";
#ifdef V_MPI
    if(MPI_ERRORS_RETURN == MPI_Init(&argc,&argv))
    {
    	char * error = "MPI_ERRORS_RETURN";
    	printf("%s",error);
    	exit MPI_ERRORS_RETURN;
    };

    MPI_Comm_size(MPI_COMM_WORLD,&numprocs);
    MPI_Comm_rank(MPI_COMM_WORLD,&rank);
    MPI_Get_processor_name(processor_name,&namelen);
    fprintf(stderr,"Process %d on %s\n",
	    rank, processor_name);

 	int buf_size = 100000000 + MPI_BSEND_OVERHEAD;
	char *p_b = new char[buf_size];
	int err_buf_att = MPI_Buffer_attach( p_b, buf_size);
	  switch (err_buf_att)
  {
  		case MPI_SUCCESS:
  					// No error
  					break;
  		case MPI_ERR_BUFFER:
  					cerr << "Invalid buffer pointer. Usually a null buffer where one is not valid. err_buf_att = " << err_buf_att << endl;
  					free(p_b);
  					exit(1);
  					break;
  		case MPI_ERR_INTERN:
			  		cerr << "An internal error has been detected. This is fatal. Please send a bug report to mpi-bugs@mcs.anl.gov. err_buf_att = " << err_buf_att << endl;
			  		free(p_b);
  					exit(1);
  					break;
  		default:
  					cerr << "Unknown error. Domain::BroadCast MPI_Buffer_attach. err_buf_att = " << err_buf_att << endl;				
  					free(p_b);
  					exit(1);
  };

#endif

  Domain *domain = new Domain(infile, rank);

#ifdef V_MPI
  //  MPI_Buffer_detach(p_b, &buf_size);
  //  delete[] p_b;
#endif

#ifdef X_ACCESS
  Plot *interactive = domain->plot;
  if (interactive->nview) {
    interactive->Run();
  }
  else {
    domain->Run();
  }
#endif
#ifdef NO_X_ACCESS
    domain->Run();
#endif
  delete domain;

#ifdef V_MPI
  MPI_Finalize();
#endif
  return 0;
}

